# Revaco

Responsive Variable Colors. A clear template with 2 colors. Will change header and footer on mobile using multiple css files. Will also use jquery to style navigation


Temporary DemoPage:

http://jsfiddle.net/DSigmund/ExGU3/4/

## Features

- Header
- Mobile
- Responsive
- Swipe
- LazyLoad

## Manual

Description of Fields, how to create FavIcon, Icons, Startup-Images

## MileStones

See Issues


## Additional Projects

- Version for Wordpress
- Version for Tools with XML-Config-File (Navigation?)
